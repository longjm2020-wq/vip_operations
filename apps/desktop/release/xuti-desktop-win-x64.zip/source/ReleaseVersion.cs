[assembly: System.Reflection.AssemblyFileVersion("1.2.13.0")]
[assembly: System.Reflection.AssemblyInformationalVersion("1.2.13")]
namespace XutiDesktop { static partial class ShellPolicy { public const string Version = "1.2.13"; } }
