[assembly: System.Reflection.AssemblyFileVersion("1.2.10.0")]
[assembly: System.Reflection.AssemblyInformationalVersion("1.2.10")]
namespace XutiDesktop { static partial class ShellPolicy { public const string Version = "1.2.10"; } }
