[assembly: System.Reflection.AssemblyFileVersion("1.3.5.0")]
[assembly: System.Reflection.AssemblyInformationalVersion("1.3.5")]
namespace XutiDesktop { static partial class ShellPolicy { public const string Version = "1.3.5"; } }
