[assembly: System.Reflection.AssemblyFileVersion("1.2.16.0")]
[assembly: System.Reflection.AssemblyInformationalVersion("1.2.16")]
namespace XutiDesktop { static partial class ShellPolicy { public const string Version = "1.2.16"; } }
