[assembly: System.Reflection.AssemblyFileVersion("1.2.18.0")]
[assembly: System.Reflection.AssemblyInformationalVersion("1.2.18")]
namespace XutiDesktop { static partial class ShellPolicy { public const string Version = "1.2.18"; } }
