[assembly: System.Reflection.AssemblyFileVersion("1.2.7.0")]
[assembly: System.Reflection.AssemblyInformationalVersion("1.2.7")]
namespace XutiDesktop { static partial class ShellPolicy { public const string Version = "1.2.7"; } }
